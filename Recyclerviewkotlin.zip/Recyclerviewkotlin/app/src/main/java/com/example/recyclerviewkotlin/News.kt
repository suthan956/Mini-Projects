package com.example.recyclerviewkotlin

data class News(var titleimage : Int,var heading : String)
